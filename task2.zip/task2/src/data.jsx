
// import PropTypes from 'prop-types';

// export default function Data({ card }) {
//   const { image, title, category, price, brand } = card;

//   return (
//     <div className="card">
//       <img src={image} alt={title} />
//       <h4 className="title">{title}</h4>
//       <p className="category">{category}</p>
//       <p className="price">{price}</p>
//       <p className="brand">{brand}</p>
//     </div>
//   );
// }

// Data.propTypes = {
//   card: PropTypes.object.isRequired,
// };