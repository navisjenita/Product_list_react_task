import Header from "./header";
import Card from"./card"



function App() {
  return (
    <div>
   <Header/>
  <Card/>
  
    </div>
  );
}

export default App;